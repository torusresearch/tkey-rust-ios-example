//
//  FFIHashTest.h
//  FFIHashTest
//
//  Created by Labs Torus on 5/9/22.
//

#import <Foundation/Foundation.h>
#import <FFIHashTest/tkey.h>

//! Project version number for FFIHashTest.
FOUNDATION_EXPORT double FFIHashTestVersionNumber;

//! Project version string for FFIHashTest.
FOUNDATION_EXPORT const unsigned char FFIHashTestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FFIHashTest/PublicHeader.h>
